Security - Login/Logout
Security - User Registration
Security - VIP Member Access
Security - Handling Browser Refresh
Security - Order History - Base Functionality
Security - Order History - Secure Backend
Security - Order History - Secure Frontend
